package package1;

public class Hijo extends Padre {

}
