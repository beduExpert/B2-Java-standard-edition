package package1;

public class Padre {
	public void baila() {
		System.out.println("Baila chachacha");
	}
}
