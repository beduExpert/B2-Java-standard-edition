
public class Producto {
	private String nombre;          //nombre
	private int porcentajeImpuesto; //porcentaje de impuesto
	private double costo;           //costo
	private String marca;           //marca
	
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public int getPorcentajeImpuesto() {
		return porcentajeImpuesto;
	}
	
	public void setPorcentajeImpuesto(int porcentajeImpuesto) {
		this.porcentajeImpuesto = porcentajeImpuesto;
	}
	
	public double getCosto() {
		return costo;
	}
	
	public void setCosto(double costo) {
		this.costo = costo;
	}
	
	public String getMarca() {
		return marca;
	}
	
	public void setMarca(String marca) {
		this.marca = marca;
	}
	
	
}
