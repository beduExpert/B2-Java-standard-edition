import java.util.*;

public class SupermercadoTest {
	public static void main(String args[]) {
		Usuario u = Usuario.registroUsuario(); //Invocando método registroUsuario(static), de la clase Usuario.
	}
}