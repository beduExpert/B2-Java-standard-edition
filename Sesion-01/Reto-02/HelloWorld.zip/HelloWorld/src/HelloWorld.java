
public class HelloWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Nombre: Dorotea");
		System.out.println("Edad: 65");
		System.out.println("Calle 10, #5");
	}

}
