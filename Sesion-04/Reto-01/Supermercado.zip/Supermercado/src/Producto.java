
public class Producto {
	public String nombre;          //nombre
	public int porcentajeImpuesto; //porcentaje de impuesto
	public double costo;           //costo
	public String marca;           //marca
}
