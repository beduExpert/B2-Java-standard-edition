
public class Usuario {
	public String usuario;         //id
	public String nombre;          //nombre
	public String fechaCumpleaños; //fechaCumpleaños
	public String direccion;       //direccion
	public String telefono;        //telefono
	
	//levantaPedido
}

//registraUsuario () //Si la edad del socio es < 18, entonces emitir un mensaje indicando, no se puede dar registro.
//De lo contrario, solicitar el resto de datos