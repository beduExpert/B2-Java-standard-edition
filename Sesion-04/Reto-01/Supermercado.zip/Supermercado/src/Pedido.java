
public class Pedido {
	public int numeroPedido;
	public double montoFinal;
	public Producto listaProducto[] = new Producto[10];
	
	//sumaCostos
	//agregarElemento
}
