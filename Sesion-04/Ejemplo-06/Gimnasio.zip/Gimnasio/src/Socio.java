
public class Socio {
	public String nombre;            //nombre
	public int numeroSocio;          //numeroSocio
	public String correoElectronico; //correoElectronico
	public String telefono;          //telefono
	public int edad;
	//actividades
}

//registraSocio () //Si la edad del socio es < 18, entonces emitir un mensaje indicando, no se puede dar registro.
                   //De lo contrario, solicitar el resto de datos