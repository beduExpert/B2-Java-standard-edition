
public class Actividad {
	public String nombre;//nombre
	public int id; //id
}
