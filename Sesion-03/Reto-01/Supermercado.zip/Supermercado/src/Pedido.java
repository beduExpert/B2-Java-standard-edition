
public class Pedido {
	public int numeroPedido;
	public double montoFinal;
	
	//listaProducto
	//sumaCostos
	//agregarElemento
}
