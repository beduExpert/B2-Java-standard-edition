
public class Usuario {
	public int id;                 //id
	public String nombre;          //nombre
	public String fechaCumpleaños; //fechaCumpleaños
	public String direccion;       //direccion
	public String telefono;        //telefono
	
	//levantaPedido
}
