 
public class Libro {

	 public int id;//#id
	 public String titulo;//título
	 public String autor;//autor
	 public String editorial;//editorial
	 public String descripcion;//descripción
	 public int numeroUnidades;//#unidades
}
