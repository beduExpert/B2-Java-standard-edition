
public class Alumno {
	 public String nombre;//Nombre
	 public int numeroCuenta;//NúmeroCuenta
	 public String correoElectronico;//CorreoElectrónico
	 //listaLibros
}
