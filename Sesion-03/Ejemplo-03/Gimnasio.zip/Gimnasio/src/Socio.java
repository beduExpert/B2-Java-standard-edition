
public class Socio {
	public String nombre;            //nombre
	public int numeroSocio;          //numeroSocio
	public String correoElectronico; //correoElectronico
	public String telefono;          //telefono
	//actividades
}
	