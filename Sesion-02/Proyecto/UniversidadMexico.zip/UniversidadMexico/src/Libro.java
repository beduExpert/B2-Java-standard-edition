 
public class Libro {

	 //#id
	 //título
	 //autor
	 //editorial
	 //descripción
	 //#unidades
}
