
public class Alumno {
	 //Nombre
	 //NúmeroCuenta
	 //CorreoElectrónico
	 //listaLibros
}
