
public class Pedido {
	//numeroPedido
	//listaProducto
	//montoFinal
	
	//sumaCostos
	//agregarElemento
	//eliminarPedido
}
