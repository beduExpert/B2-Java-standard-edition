
public class Producto {
	//nombre
	//porcentaje de impuesto
	//costo
	//marca
}
