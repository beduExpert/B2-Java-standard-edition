
public class Actividad {
	//nombre
	//id
}
