
public class Actividades {
	//nombre
	//id
}
