
public class GimnasioTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Actividad a = new Actividad();
		Socio s = new Socio();
		System.out.println("Terminando de crear instancias...");
	}

}
