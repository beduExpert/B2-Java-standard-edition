
public class GimnasioTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Actividad a = new Actividad(); //Declarando una instancia de tipo Actividad
		Socio s = new Socio(); //Declarando una instancia de tipo socio
		System.out.println("Terminando de crear instancias...");
	}
}
