
public class Socio {
	//nombre
	//numeroSocio
	//correoElectronico
	//telefono
	//actividades
}
	