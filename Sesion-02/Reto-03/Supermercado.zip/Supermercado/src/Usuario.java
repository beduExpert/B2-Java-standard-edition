
public class Usuario {
	//id
	//nombre
	//fechaCumpleaños
	//direccion
	//telefono
	
	//levantaPedido
}
