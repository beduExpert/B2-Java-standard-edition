
public class SupermercadoTest {
	public static void main(String args[]) {
		Pedido p = new Pedido();//Declarando instancia de tipo Pedido.
		Producto pr = new Producto(); //Declarando instancia de tipo Producto
		Usuario s = new Usuario(); //Declarando instancia de tipo Supermercado.
		System.out.println("Terminando de declarar instancias...");
	}
}
